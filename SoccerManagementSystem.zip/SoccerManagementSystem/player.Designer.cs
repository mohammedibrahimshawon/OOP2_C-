﻿
namespace SoccerManagementSystem
{
    partial class player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_monitor_button = new System.Windows.Forms.Button();
            this.w_monitor_button = new System.Windows.Forms.Button();
            this.p_h__textBox_id = new System.Windows.Forms.TextBox();
            this.p_h__textBox_jerseyNo = new System.Windows.Forms.TextBox();
            this.p_h__textBox_position = new System.Windows.Forms.TextBox();
            this.p_h_label_id = new System.Windows.Forms.Label();
            this.p_h_label_position = new System.Windows.Forms.Label();
            this.p_h__textBox_name = new System.Windows.Forms.TextBox();
            this.p_h_label_name = new System.Windows.Forms.Label();
            this.p_h_label_jersy_no = new System.Windows.Forms.Label();
            this.inchtextbox = new System.Windows.Forms.TextBox();
            this.metretextbox = new System.Windows.Forms.TextBox();
            this.p_h_label_inchtometre = new System.Windows.Forms.Label();
            this.bmiresult = new System.Windows.Forms.TextBox();
            this.weighttextbox = new System.Windows.Forms.TextBox();
            this.heighttextbox = new System.Windows.Forms.TextBox();
            this.p_h_label_bmiresult = new System.Windows.Forms.Label();
            this.p_h__button_calculate = new System.Windows.Forms.Button();
            this.p_h_label_kg = new System.Windows.Forms.Label();
            this.p_h_label_mitre = new System.Windows.Forms.Label();
            this.p_h_label_weight = new System.Windows.Forms.Label();
            this.p_h_label_height = new System.Windows.Forms.Label();
            this.p_h_label_bmicalculator = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // m_monitor_button
            // 
            this.m_monitor_button.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.m_monitor_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_monitor_button.Location = new System.Drawing.Point(376, 339);
            this.m_monitor_button.Name = "m_monitor_button";
            this.m_monitor_button.Size = new System.Drawing.Size(161, 80);
            this.m_monitor_button.TabIndex = 55;
            this.m_monitor_button.Text = "Performance Monitor";
            this.m_monitor_button.UseVisualStyleBackColor = false;
            this.m_monitor_button.Click += new System.EventHandler(this.button3_Click);
            // 
            // w_monitor_button
            // 
            this.w_monitor_button.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.w_monitor_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w_monitor_button.Location = new System.Drawing.Point(124, 339);
            this.w_monitor_button.Name = "w_monitor_button";
            this.w_monitor_button.Size = new System.Drawing.Size(161, 80);
            this.w_monitor_button.TabIndex = 54;
            this.w_monitor_button.Text = "Workout Monitor";
            this.w_monitor_button.UseVisualStyleBackColor = false;
            this.w_monitor_button.Click += new System.EventHandler(this.button2_Click);
            // 
            // p_h__textBox_id
            // 
            this.p_h__textBox_id.Font = new System.Drawing.Font("MS Reference Specialty", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.p_h__textBox_id.Location = new System.Drawing.Point(168, 59);
            this.p_h__textBox_id.Margin = new System.Windows.Forms.Padding(4);
            this.p_h__textBox_id.Name = "p_h__textBox_id";
            this.p_h__textBox_id.Size = new System.Drawing.Size(118, 32);
            this.p_h__textBox_id.TabIndex = 53;
            // 
            // p_h__textBox_jerseyNo
            // 
            this.p_h__textBox_jerseyNo.Font = new System.Drawing.Font("MS Reference Specialty", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.p_h__textBox_jerseyNo.Location = new System.Drawing.Point(168, 173);
            this.p_h__textBox_jerseyNo.Margin = new System.Windows.Forms.Padding(4);
            this.p_h__textBox_jerseyNo.Name = "p_h__textBox_jerseyNo";
            this.p_h__textBox_jerseyNo.Size = new System.Drawing.Size(65, 32);
            this.p_h__textBox_jerseyNo.TabIndex = 52;
            // 
            // p_h__textBox_position
            // 
            this.p_h__textBox_position.Font = new System.Drawing.Font("MS Reference Specialty", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.p_h__textBox_position.Location = new System.Drawing.Point(168, 224);
            this.p_h__textBox_position.Margin = new System.Windows.Forms.Padding(4);
            this.p_h__textBox_position.Name = "p_h__textBox_position";
            this.p_h__textBox_position.Size = new System.Drawing.Size(149, 32);
            this.p_h__textBox_position.TabIndex = 51;
            // 
            // p_h_label_id
            // 
            this.p_h_label_id.AutoSize = true;
            this.p_h_label_id.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_id.Location = new System.Drawing.Point(42, 59);
            this.p_h_label_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_id.Name = "p_h_label_id";
            this.p_h_label_id.Size = new System.Drawing.Size(41, 27);
            this.p_h_label_id.TabIndex = 50;
            this.p_h_label_id.Text = "ID:";
            // 
            // p_h_label_position
            // 
            this.p_h_label_position.AutoSize = true;
            this.p_h_label_position.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_position.Location = new System.Drawing.Point(42, 224);
            this.p_h_label_position.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_position.Name = "p_h_label_position";
            this.p_h_label_position.Size = new System.Drawing.Size(100, 27);
            this.p_h_label_position.TabIndex = 49;
            this.p_h_label_position.Text = "Position:";
            // 
            // p_h__textBox_name
            // 
            this.p_h__textBox_name.Font = new System.Drawing.Font("MS Reference Specialty", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.p_h__textBox_name.Location = new System.Drawing.Point(168, 117);
            this.p_h__textBox_name.Margin = new System.Windows.Forms.Padding(4);
            this.p_h__textBox_name.Name = "p_h__textBox_name";
            this.p_h__textBox_name.Size = new System.Drawing.Size(305, 32);
            this.p_h__textBox_name.TabIndex = 48;
            // 
            // p_h_label_name
            // 
            this.p_h_label_name.AutoSize = true;
            this.p_h_label_name.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_name.Location = new System.Drawing.Point(42, 117);
            this.p_h_label_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_name.Name = "p_h_label_name";
            this.p_h_label_name.Size = new System.Drawing.Size(85, 27);
            this.p_h_label_name.TabIndex = 47;
            this.p_h_label_name.Text = "Name: ";
            // 
            // p_h_label_jersy_no
            // 
            this.p_h_label_jersy_no.AutoSize = true;
            this.p_h_label_jersy_no.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_jersy_no.Location = new System.Drawing.Point(42, 173);
            this.p_h_label_jersy_no.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_jersy_no.Name = "p_h_label_jersy_no";
            this.p_h_label_jersy_no.Size = new System.Drawing.Size(119, 27);
            this.p_h_label_jersy_no.TabIndex = 46;
            this.p_h_label_jersy_no.Text = "Jersey_No:";
            this.p_h_label_jersy_no.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // inchtextbox
            // 
            this.inchtextbox.Location = new System.Drawing.Point(912, 148);
            this.inchtextbox.Margin = new System.Windows.Forms.Padding(4);
            this.inchtextbox.Name = "inchtextbox";
            this.inchtextbox.Size = new System.Drawing.Size(64, 22);
            this.inchtextbox.TabIndex = 45;
            this.inchtextbox.TextChanged += new System.EventHandler(this.inchtextbox_TextChanged);
            // 
            // metretextbox
            // 
            this.metretextbox.Location = new System.Drawing.Point(993, 148);
            this.metretextbox.Margin = new System.Windows.Forms.Padding(4);
            this.metretextbox.Name = "metretextbox";
            this.metretextbox.Size = new System.Drawing.Size(69, 22);
            this.metretextbox.TabIndex = 44;
            // 
            // p_h_label_inchtometre
            // 
            this.p_h_label_inchtometre.AutoSize = true;
            this.p_h_label_inchtometre.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_inchtometre.Location = new System.Drawing.Point(908, 117);
            this.p_h_label_inchtometre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_inchtometre.Name = "p_h_label_inchtometre";
            this.p_h_label_inchtometre.Size = new System.Drawing.Size(154, 23);
            this.p_h_label_inchtometre.TabIndex = 43;
            this.p_h_label_inchtometre.Text = "(Inch)  to  (Metre)";
            // 
            // bmiresult
            // 
            this.bmiresult.Location = new System.Drawing.Point(757, 330);
            this.bmiresult.Margin = new System.Windows.Forms.Padding(4);
            this.bmiresult.Name = "bmiresult";
            this.bmiresult.Size = new System.Drawing.Size(104, 22);
            this.bmiresult.TabIndex = 42;
            // 
            // weighttextbox
            // 
            this.weighttextbox.Location = new System.Drawing.Point(748, 209);
            this.weighttextbox.Margin = new System.Windows.Forms.Padding(4);
            this.weighttextbox.Name = "weighttextbox";
            this.weighttextbox.Size = new System.Drawing.Size(104, 22);
            this.weighttextbox.TabIndex = 41;
            // 
            // heighttextbox
            // 
            this.heighttextbox.Location = new System.Drawing.Point(748, 144);
            this.heighttextbox.Margin = new System.Windows.Forms.Padding(4);
            this.heighttextbox.Name = "heighttextbox";
            this.heighttextbox.Size = new System.Drawing.Size(104, 22);
            this.heighttextbox.TabIndex = 40;
            // 
            // p_h_label_bmiresult
            // 
            this.p_h_label_bmiresult.AutoSize = true;
            this.p_h_label_bmiresult.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_bmiresult.Location = new System.Drawing.Point(660, 330);
            this.p_h_label_bmiresult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_bmiresult.Name = "p_h_label_bmiresult";
            this.p_h_label_bmiresult.Size = new System.Drawing.Size(89, 23);
            this.p_h_label_bmiresult.TabIndex = 39;
            this.p_h_label_bmiresult.Text = "Your BMI:";
            // 
            // p_h__button_calculate
            // 
            this.p_h__button_calculate.BackColor = System.Drawing.SystemColors.Highlight;
            this.p_h__button_calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h__button_calculate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.p_h__button_calculate.Location = new System.Drawing.Point(748, 266);
            this.p_h__button_calculate.Margin = new System.Windows.Forms.Padding(4);
            this.p_h__button_calculate.Name = "p_h__button_calculate";
            this.p_h__button_calculate.Size = new System.Drawing.Size(120, 36);
            this.p_h__button_calculate.TabIndex = 38;
            this.p_h__button_calculate.Text = "Calculate";
            this.p_h__button_calculate.UseVisualStyleBackColor = false;
            this.p_h__button_calculate.Click += new System.EventHandler(this.p_h__button_calculate_Click);
            // 
            // p_h_label_kg
            // 
            this.p_h_label_kg.AutoSize = true;
            this.p_h_label_kg.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_kg.Location = new System.Drawing.Point(753, 238);
            this.p_h_label_kg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_kg.Name = "p_h_label_kg";
            this.p_h_label_kg.Size = new System.Drawing.Size(46, 23);
            this.p_h_label_kg.TabIndex = 37;
            this.p_h_label_kg.Text = "(KG)";
            // 
            // p_h_label_mitre
            // 
            this.p_h_label_mitre.AutoSize = true;
            this.p_h_label_mitre.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_mitre.Location = new System.Drawing.Point(753, 173);
            this.p_h_label_mitre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_mitre.Name = "p_h_label_mitre";
            this.p_h_label_mitre.Size = new System.Drawing.Size(66, 23);
            this.p_h_label_mitre.TabIndex = 36;
            this.p_h_label_mitre.Text = "(Mitre)";
            // 
            // p_h_label_weight
            // 
            this.p_h_label_weight.AutoSize = true;
            this.p_h_label_weight.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_weight.Location = new System.Drawing.Point(621, 211);
            this.p_h_label_weight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_weight.Name = "p_h_label_weight";
            this.p_h_label_weight.Size = new System.Drawing.Size(115, 23);
            this.p_h_label_weight.TabIndex = 35;
            this.p_h_label_weight.Text = "Your Weight:";
            // 
            // p_h_label_height
            // 
            this.p_h_label_height.AutoSize = true;
            this.p_h_label_height.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_height.Location = new System.Drawing.Point(621, 145);
            this.p_h_label_height.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_height.Name = "p_h_label_height";
            this.p_h_label_height.Size = new System.Drawing.Size(111, 23);
            this.p_h_label_height.TabIndex = 34;
            this.p_h_label_height.Text = "Your Height:";
            // 
            // p_h_label_bmicalculator
            // 
            this.p_h_label_bmicalculator.AutoSize = true;
            this.p_h_label_bmicalculator.Font = new System.Drawing.Font("Microsoft YaHei", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_h_label_bmicalculator.Location = new System.Drawing.Point(697, 84);
            this.p_h_label_bmicalculator.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.p_h_label_bmicalculator.Name = "p_h_label_bmicalculator";
            this.p_h_label_bmicalculator.Size = new System.Drawing.Size(161, 27);
            this.p_h_label_bmicalculator.TabIndex = 33;
            this.p_h_label_bmicalculator.Text = "BMI Calculator";
            // 
            // player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SoccerManagementSystem.Properties.Resources.stadium;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1113, 562);
            this.Controls.Add(this.m_monitor_button);
            this.Controls.Add(this.w_monitor_button);
            this.Controls.Add(this.p_h__textBox_id);
            this.Controls.Add(this.p_h__textBox_jerseyNo);
            this.Controls.Add(this.p_h__textBox_position);
            this.Controls.Add(this.p_h_label_id);
            this.Controls.Add(this.p_h_label_position);
            this.Controls.Add(this.p_h__textBox_name);
            this.Controls.Add(this.p_h_label_name);
            this.Controls.Add(this.p_h_label_jersy_no);
            this.Controls.Add(this.inchtextbox);
            this.Controls.Add(this.metretextbox);
            this.Controls.Add(this.p_h_label_inchtometre);
            this.Controls.Add(this.bmiresult);
            this.Controls.Add(this.weighttextbox);
            this.Controls.Add(this.heighttextbox);
            this.Controls.Add(this.p_h_label_bmiresult);
            this.Controls.Add(this.p_h__button_calculate);
            this.Controls.Add(this.p_h_label_kg);
            this.Controls.Add(this.p_h_label_mitre);
            this.Controls.Add(this.p_h_label_weight);
            this.Controls.Add(this.p_h_label_height);
            this.Controls.Add(this.p_h_label_bmicalculator);
            this.Name = "player";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "player";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.player_home_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_monitor_button;
        private System.Windows.Forms.Button w_monitor_button;
        private System.Windows.Forms.TextBox p_h__textBox_id;
        private System.Windows.Forms.TextBox p_h__textBox_jerseyNo;
        private System.Windows.Forms.TextBox p_h__textBox_position;
        private System.Windows.Forms.Label p_h_label_id;
        private System.Windows.Forms.Label p_h_label_position;
        private System.Windows.Forms.TextBox p_h__textBox_name;
        private System.Windows.Forms.Label p_h_label_name;
        private System.Windows.Forms.Label p_h_label_jersy_no;
        private System.Windows.Forms.TextBox inchtextbox;
        private System.Windows.Forms.TextBox metretextbox;
        private System.Windows.Forms.Label p_h_label_inchtometre;
        private System.Windows.Forms.TextBox bmiresult;
        private System.Windows.Forms.TextBox weighttextbox;
        private System.Windows.Forms.TextBox heighttextbox;
        private System.Windows.Forms.Label p_h_label_bmiresult;
        private System.Windows.Forms.Button p_h__button_calculate;
        private System.Windows.Forms.Label p_h_label_kg;
        private System.Windows.Forms.Label p_h_label_mitre;
        private System.Windows.Forms.Label p_h_label_weight;
        private System.Windows.Forms.Label p_h_label_height;
        private System.Windows.Forms.Label p_h_label_bmicalculator;
    }
}