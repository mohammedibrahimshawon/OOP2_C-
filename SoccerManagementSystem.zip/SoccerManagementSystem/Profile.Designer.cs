﻿
namespace SoccerManagementSystem
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "Profile";

            this.button3 = new System.Windows.Forms.Button();
            this.genderlb = new System.Windows.Forms.Label();
            this.phonelb = new System.Windows.Forms.Label();
            this.emaillb = new System.Windows.Forms.Label();
            this.addresslb = new System.Windows.Forms.Label();
            this.namelb = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.Homebutton = new System.Windows.Forms.Button();
            this.joindatelb = new System.Windows.Forms.Label();
            this.salarylb = new System.Windows.Forms.Label();
            this.nidlb = new System.Windows.Forms.Label();
            this.typelb = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(13, 14);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 66);
            this.button3.TabIndex = 62;
            this.button3.Text = "Edit Profile";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // genderlb
            // 
            this.genderlb.AutoSize = true;
            this.genderlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderlb.Location = new System.Drawing.Point(406, 231);
            this.genderlb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.genderlb.Name = "genderlb";
            this.genderlb.Size = new System.Drawing.Size(94, 29);
            this.genderlb.TabIndex = 61;
            this.genderlb.Text = "Gender";
            // 
            // phonelb
            // 
            this.phonelb.AutoSize = true;
            this.phonelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonelb.Location = new System.Drawing.Point(406, 202);
            this.phonelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.phonelb.Name = "phonelb";
            this.phonelb.Size = new System.Drawing.Size(83, 29);
            this.phonelb.TabIndex = 60;
            this.phonelb.Text = "Phone";
            // 
            // emaillb
            // 
            this.emaillb.AutoSize = true;
            this.emaillb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emaillb.Location = new System.Drawing.Point(406, 173);
            this.emaillb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emaillb.Name = "emaillb";
            this.emaillb.Size = new System.Drawing.Size(82, 29);
            this.emaillb.TabIndex = 59;
            this.emaillb.Text = "E-Mail";
            // 
            // addresslb
            // 
            this.addresslb.AutoSize = true;
            this.addresslb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslb.Location = new System.Drawing.Point(406, 135);
            this.addresslb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.addresslb.Name = "addresslb";
            this.addresslb.Size = new System.Drawing.Size(102, 29);
            this.addresslb.TabIndex = 58;
            this.addresslb.Text = "Address";
            // 
            // namelb
            // 
            this.namelb.AutoSize = true;
            this.namelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelb.Location = new System.Drawing.Point(406, 97);
            this.namelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.namelb.Name = "namelb";
            this.namelb.Size = new System.Drawing.Size(78, 29);
            this.namelb.TabIndex = 57;
            this.namelb.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(215, 231);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 29);
            this.label6.TabIndex = 56;
            this.label6.Text = "Gender:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(226, 202);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 29);
            this.label4.TabIndex = 55;
            this.label4.Text = "Phone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(227, 164);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 29);
            this.label3.TabIndex = 54;
            this.label3.Text = "E-Mail:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 135);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 29);
            this.label2.TabIndex = 53;
            this.label2.Text = "Address:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(215, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 29);
            this.label1.TabIndex = 52;
            this.label1.Text = "Name:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(630, 90);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(193, 65);
            this.button2.TabIndex = 72;
            this.button2.Text = "Logout";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Homebutton
            // 
            this.Homebutton.Location = new System.Drawing.Point(630, 15);
            this.Homebutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Homebutton.Name = "Homebutton";
            this.Homebutton.Size = new System.Drawing.Size(193, 65);
            this.Homebutton.TabIndex = 71;
            this.Homebutton.Text = "Home";
            this.Homebutton.UseVisualStyleBackColor = true;
            this.Homebutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // joindatelb
            // 
            this.joindatelb.AutoSize = true;
            this.joindatelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.joindatelb.Location = new System.Drawing.Point(406, 347);
            this.joindatelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.joindatelb.Name = "joindatelb";
            this.joindatelb.Size = new System.Drawing.Size(114, 29);
            this.joindatelb.TabIndex = 70;
            this.joindatelb.Text = "Join Date";
            // 
            // salarylb
            // 
            this.salarylb.AutoSize = true;
            this.salarylb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salarylb.Location = new System.Drawing.Point(406, 318);
            this.salarylb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.salarylb.Name = "salarylb";
            this.salarylb.Size = new System.Drawing.Size(80, 29);
            this.salarylb.TabIndex = 69;
            this.salarylb.Text = "Salary";
            // 
            // nidlb
            // 
            this.nidlb.AutoSize = true;
            this.nidlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nidlb.Location = new System.Drawing.Point(406, 289);
            this.nidlb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nidlb.Name = "nidlb";
            this.nidlb.Size = new System.Drawing.Size(54, 29);
            this.nidlb.TabIndex = 68;
            this.nidlb.Text = "NID";
            // 
            // typelb
            // 
            this.typelb.AutoSize = true;
            this.typelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typelb.Location = new System.Drawing.Point(406, 260);
            this.typelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.typelb.Name = "typelb";
            this.typelb.Size = new System.Drawing.Size(68, 29);
            this.typelb.TabIndex = 67;
            this.typelb.Text = "Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(195, 347);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 29);
            this.label10.TabIndex = 66;
            this.label10.Text = "Join Date:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(229, 318);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 29);
            this.label9.TabIndex = 65;
            this.label9.Text = "Salary:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(258, 289);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 29);
            this.label8.TabIndex = 64;
            this.label8.Text = "NID:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(241, 260);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 29);
            this.label7.TabIndex = 63;
            this.label7.Text = "Type:";
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 395);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Homebutton);
            this.Controls.Add(this.joindatelb);
            this.Controls.Add(this.salarylb);
            this.Controls.Add(this.nidlb);
            this.Controls.Add(this.typelb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.genderlb);
            this.Controls.Add(this.phonelb);
            this.Controls.Add(this.emaillb);
            this.Controls.Add(this.addresslb);
            this.Controls.Add(this.namelb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Profile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        //#endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label genderlb;
        private System.Windows.Forms.Label phonelb;
        private System.Windows.Forms.Label emaillb;
        private System.Windows.Forms.Label addresslb;
        private System.Windows.Forms.Label namelb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Homebutton;
        private System.Windows.Forms.Label joindatelb;
        private System.Windows.Forms.Label salarylb;
        private System.Windows.Forms.Label nidlb;
        private System.Windows.Forms.Label typelb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

#endregion